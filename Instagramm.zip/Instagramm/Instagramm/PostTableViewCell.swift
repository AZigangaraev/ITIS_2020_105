//
//  PostTableViewCell.swift
//  Instagramm
//
//  Created by Albert Ahmadiev on 08.10.2020.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    @IBOutlet var authorImage: UIImageView!
    @IBOutlet var authorName: UILabel!
    @IBOutlet var postImage: UIImageView!
    @IBOutlet var likeButton: UIButton!
    @IBOutlet var countOfLike: UILabel!
    @IBOutlet var authorComment: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    public func fillPost(authorImage: UIImage, authorName: String, postImage: UIImage, authorComment: String){
        self.authorComment.text = authorComment
        self.authorName.text = authorName
        self.postImage.image = postImage
        self.authorImage.image = authorImage
    }

}
