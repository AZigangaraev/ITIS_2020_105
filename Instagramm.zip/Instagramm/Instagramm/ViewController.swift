//
//  ViewController.swift
//  Instagramm
//
//  Created by Albert Ahmadiev on 05.10.2020.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var postsTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.postsTable.delegate = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "postCell", for: indexPath) as! PostTableViewCell
        cell.fillPost(authorImage: #imageLiteral(resourceName: "67310557_649773548849427_4130659181743046656_n.jpg"), authorName: "cristiano", postImage: #imageLiteral(resourceName: "c_ScFZ2tnXw.jpg"), authorComment:
                      "Excelente trabalho equipa!👏🏽 \n Continuar a trabalhar com a mesma atitude e \n ambição para conseguirmos o nosso objetivo principal! 💪🏽\n Obrigado pelo apoio, juntos somos mais fortes! 🇵🇹💪🏽")
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
}

